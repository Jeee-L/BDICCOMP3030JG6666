<script>
const topbarMenu = [
  { path: "/employee/home", icon: "fa fa-th", title: "Employee Home" },
  { path: "/employee/insurance", icon: "fa fa-hdd", title: "Insurance" },
  { path: "/employee/baggage", icon: "fa fa-hdd", title: "Baggage Registration" },
  { path: "/employee/claim", icon: "fa fa-hdd", title: "Claim" },
];

export default topbarMenu;
</script>
