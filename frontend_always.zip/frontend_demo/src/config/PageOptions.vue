<script>
const pageOptions = {
  pageSidebarMinified: false,
  pageContentFullWidth: false,
  pageContentInverseMode: false,
  pageContentFullHeight: false,
  pageWithLanguageBar: true,
  pageWithFooter: false,
  pageWithoutSidebar: false,
  pageWithRightSidebar: false,
  pageWithTwoSidebar: false,
  pageWithTopMenu: false,
  pageWithWideSidebar: false,
  pageWithLightSidebar: false,
  pageWithMegaMenu: false,
  pageSidebarTransparent: true,
  pageEmpty: false,
  pageMobileSidebarToggled: false,
  pageMobileRightSidebarToggled: false,
  pageMobileTopMenu: false,
  pageMobileMegaMenu: false,
  pageRightSidebarToggled: false,
  pageBodyScrollTop: 0
}

export default pageOptions;
</script>
