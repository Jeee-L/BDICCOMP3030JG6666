# Changelog

##[1.1.0] 2019-02-12
- Package updates
- SSR fixes for checkboxes and radio
- IE fixes
- Best practices & accessibility improvements + pwa support

## [1.0.0] 2018-08-14
Initial stable release
### Original Release
